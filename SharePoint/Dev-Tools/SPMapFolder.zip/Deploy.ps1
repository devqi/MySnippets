﻿param (
    [switch] $Remove
)

function Deploy-Solution()
{
    $local:source = (Resolve-Path -LiteralPath ".\spmapfolder.wsp").Path
    $local:name = [System.IO.Path]::GetFileName($local:source)
    $local:solution = Get-SPSolution | Where { $_.Name -eq $local:name }
    if ($local:solution -ne $null)
    {
        foreach ($local:feature in (Get-SPFeature | Where { $_.SolutionId -eq $local:solution.SolutionId }))
        {
            Write-Host ([string]::Format("Uninstalling feature {0}", $local:feature.DisplayName))
            Uninstall-SPFeature -Identity $local:feature.Id -Confirm:$false
        }

        if ($local:solution.Deployed)
        {
            Write-Host "Uninstalling solution"
            Uninstall-SPSolution -Identity $local:solution.SolutionId -Confirm:$false
            do
            {
                Start-Sleep -Milliseconds 500
                $local:solution = Get-SPSolution | Where { $_.Name -eq $local:name }
            } while ($local:solution -ne $null -and $local:solution.Deployed)

            do
            {
                Start-Sleep -Milliseconds 500
            } while ($local:solution.JobExists)
        }

        Write-Host "Removing solution"
        Remove-SPSolution -Identity $local:solution.SolutionId -Confirm:$false
        do
        {
            Start-Sleep -Milliseconds 500
            $local:solution = Get-SPSolution | Where { $_.Name -eq $local:name }
        } while ($local:solution -ne $null)
    }

    if ($Remove)
    {
        return
    }

    Write-Host "Adding solution"
    $local:solution = Add-SPSolution -LiteralPath $local:source

    Write-Host "Installing solution"
    Install-SPSolution -Identity $local:solution.SolutionId -GACDeployment
    do
    {
        Start-Sleep -Milliseconds 500
        $local:solution = Get-SPSolution | Where { $_.Name -eq $local:name }
    } while ($local:solution -eq $null -or !$local:solution.Deployed)

    Write-Host "Resetting IIS"
    iisreset /restart

    Write-Host "Done"
}

Deploy-Solution